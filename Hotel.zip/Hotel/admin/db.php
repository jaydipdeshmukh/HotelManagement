<?php
$con = mysqli_connect("localhost", "root", "", "hotel") or die("Connection failed: " . mysqli_connect_error());
